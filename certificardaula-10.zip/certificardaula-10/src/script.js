function mudartema() {
  document.body.classList.toggle("dark");
}
